# -*- coding: utf-8 -*-

"""The setup script."""

from setuptools import setup

setup()
